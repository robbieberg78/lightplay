var EventEmitter = require('events');
var util = require('util');

    function SearchManager (pluginName) {
        //extends EventEmitter
        EventEmitter.call(this);
        var self = this;

        var kSearchRequestTimeout = 3 * 1000; // milliseconds
        var searchRequestIntervalId = null;

        var kNumSamples = 3;
        var kSearchCheckInterval = 1000; // milliseconds
        var kSearchTime = 30 * 1000; // milliseconds

        var searchIntervalId = null;
        var remainingSearchDuration = 0; // milliseconds

        var bestDevice = null;
        var bestCount = 0;

        self.getBestDevice = function () {
            return (bestCount > kNumSamples) ? bestDevice : null;
        };

        self.deviceWasClosed = function (deviceId) {
            if (bestDevice && (bestDevice.id == deviceId)) {
                bestDevice = null;
                self.emit("invalidate", {type: 'SEARCH_WAS_REQUESTED', pluginType: pluginName});
                self.emit("invalidate", {type: 'RESET',  pluginType: pluginName});
            }
        };

        self.socketWasClosed = function (deviceId){
             if (bestDevice && (bestDevice.id == deviceId)) {
                bestDevice = null;
                self.emit("invalidate", {type: 'RESET',  pluginType: pluginName});
            }
        }

        self.refreshUI = function () {
            self.emit("invalidate", {type: 'SEARCH_DID_UPDATE', device: bestDevice, pluginType: pluginName});
        };

        self.isSearchInProgress = function () {
            return searchIntervalId != null;
        };

        self.startOrExtendSearchRequest = function () {
            if (searchRequestIntervalId != null) {
                clearTimeout(searchRequestIntervalId);
            }
            else {
                // show UI only once per search-request-session to approximate once per extension-add
                self.emit("invalidate", {type: 'GO_TO_VIEW', pluginType: pluginName});
                self.emit("showUI");
            }
            searchRequestIntervalId = setTimeout(function () {
                stopSearchRequest();
            }, kSearchRequestTimeout);

            self.emit("invalidate", {type: 'SEARCH_WAS_REQUESTED', pluginType: pluginName});
        };

        function stopSearchRequest () {
            if (searchRequestIntervalId != null) {
                clearTimeout(searchRequestIntervalId);
                searchRequestIntervalId = null;
                self.emit("invalidate", {type: 'SEARCH_REQUEST_EXPIRED', pluginType: pluginName});
            }
            self.stopSearching();
        }

        self.startSearching = function () {
            if (searchIntervalId == null) {
                bestDevice = null;
                bestCount = 0;
                self.emit("invalidate", {type: 'SEARCH_DID_START', pluginType: pluginName});
                searchIntervalId = setInterval(checkSearching, kSearchCheckInterval);
                remainingSearchDuration = Math.max(remainingSearchDuration, kSearchTime);
            }
        };

        function checkSearching () {
            collectSearchSample();

            if (remainingSearchDuration <= kSearchCheckInterval) {
                self.stopSearching();
            }
            else {
                remainingSearchDuration -= kSearchCheckInterval;
            }

            self.refreshUI();
        }

        self.handleList = function (req, res, next) {
            var bestDevice = self.getBestDevice();
            self.startOrExtendSearchRequest();
            var list = JSON.stringify(bestDevice ? [bestDevice.id] : []);
            res.send(list);
            next();
        };

        self.stopSearching = function () {
            if (searchIntervalId != null) {
                self.emit("invalidate", {type: 'SEARCH_DID_STOP', pluginType: pluginName});
                clearInterval(searchIntervalId);
                remainingSearchDuration = 0;
                searchIntervalId = null;
            }
        };

        self.connectedToDevice = function () {
            if(self.getBestDevice()){
                self.emit("invalidate", {type: 'DEVICE_WAS_CONNECTED', pluginType: pluginName}); 
                self.emit("invalidate", {type: 'SEARCH_REQUEST_EXPIRED', pluginType: pluginName});
                if (searchIntervalId != null) {
                    clearInterval(searchIntervalId);
                    remainingSearchDuration = 0;
                    searchIntervalId = null;
                    searchRequestIntervalId = null;
                }
            }
        };

        this.lastSearchSample = [];

        function collectSearchSample () {
            self.lastSearchSample = [];
            self.emit("listRequest");
            self.lastSearchSample = self.lastSearchSample.filter(function (device) {
                return !device.connected;
            });

            var newBestDevice;
            if (self.lastSearchSample.length > 0) {
                // sort by decreasing signal strength
                self.lastSearchSample.sort(function (lhs, rhs) {
                    return lhs.device.compare(rhs.device);
                });
                newBestDevice = self.lastSearchSample[0];
            }
            else {
                newBestDevice = null;
            }

            if (bestDevice && newBestDevice && bestDevice.id == newBestDevice.id) {
                bestCount++;
            }
            else {
                bestCount = 0;
            }

            // always keep the freshest data
            bestDevice = newBestDevice;
        }

        this.onWebViewMessage = function(message){
            self.emit(message.action, message);
            switch(message.action){
                case 'beginSearch':
                    if(!self.isSearchInProgress()){
                        self.startSearching();
                    }
                    break;
                case 'closeDevice':
                    break;
            }
        };
    }
util.inherits(SearchManager, EventEmitter);
module.exports = SearchManager;

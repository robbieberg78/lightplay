process.background = true; // must come before require('Common')
require('Common');
var SearchManager = require('./searchManager');
var searchManagers = {};

var ScratchDeviceServer = function (deviceManager) {
    var self = this;
    var express = require('express');
    var fs = require('fs');
    var socketIO = require('socket.io');

    var app = express();
    var io = socketIO();

    app.use(express.static('test-client'));

    // CORS
    app.use(function (req, res, next) {
        // TODO: restrict this before adding more devices. Allow user config?
        res.header('Access-Control-Allow-Origin', '*');

        next();
    });

    app.get("/:pluginName/list", function(req, res, next){
        var name = req.params.pluginName;
        if(!plugins[name]){
            var query = JSON.parse(req.query.data);
            var type = query.type || name;
            var device_info = query.info;
            if(pluginTypes[type]){
                var searchManager = new SearchManager(name);
                deviceManager.addSearchManager(searchManager, name);
                var pluginObject = new pluginTypes[type](app, searchManagers[name], device_info);
                self.registerPlugin(pluginObject, name, type);
            }
            else{
                console.log("error");
                res.status(404).end();
                return;
            }
        }
        searchManagers[name].handleList(req, res, next);
    });

    self.registerPlugin = function (pluginObject, pluginName, pluginType) {
        plugins[pluginName] = pluginObject;
        var pluginPath = "/" + pluginName + "/" + pluginType;
        io.of(pluginPath).use(function (socket, next) {
            pluginObject.handleConnect(socket, next);
        });
    };

    function startServer (theServer, portNum) {
        theServer.listen(portNum, function () {
            console.log('listening on *:' + portNum);
        });
    }

    var sslOptions = {
        key: fs.readFileSync('ssl/scratch-device-manager.key'),
        cert: fs.readFileSync('ssl/scratch-device-manager.crt')
    };

    var https = require('https');
    var server = https.Server(sslOptions, app);
    io.attach(server);
    startServer(server, process.env.PORT || 3030);

    if (process.env.HTTP_PORT) {
        var http = require('http');
        var server_insecure = http.Server(app);
        io.attach(server_insecure);
        startServer(server_insecure, process.env.HTTP_PORT || 3000);
    }
};

var ScratchDeviceManager = function () {
    var self = this;

    var open = require('open');
    var os = require('os');

    var sb = new StatusBar();
    sb.enabled = true;
    sb.tooltip = 'Scratch Device Manager';
    sb.addEventListener('click', function () { self.showUI(); });
    application.exitAfterWindowsClose = false;

    function setStatusBarIcon () {
        // Default to 'light' if appearance is unknown
        var appearance = (application.appearance == 'dark' ? 'dark' : 'light');
        sb.image = 'app://media/status-bar-' + appearance + 'UI.png';
    }
    setStatusBarIcon();
    application.addEventListener('appearance-change', setStatusBarIcon);

    initUI();

    var popOver;
    var webView;

    function initUI () {
        if (!popOver) {
            popOver = new PopOver();
            popOver.title = 'Scratch Device Manager';
        }

        if (!webView) {
            webView = new WebView();
            while (popOver.firstChild) {
                popOver.removeChild(popOver.firstChild);
            }
            popOver.appendChild(webView);
            webView.left = webView.right = webView.top = webView.bottom = 0;

            webView.addEventListener('load', onWebViewLoaded);
            webView.addEventListener('message', onWebViewMessage);

            webView.location = 'app://ui/home.html';
        }

        // TODO: can the dimensions be specified by the content somehow?
        popOver.width = 280;
        popOver.height = 360;
    }

    self.showUI = function () {
        initUI();
        popOver.open(sb, 'bottom');
    };

    function onWebViewLoaded () {
        // See: https://github.com/trueinteractions/tint2/issues/139
        if (os.platform() == 'darwin') {
            application.native('activateIgnoringOtherApps', true);
        }
        popOver.focus();
        webView.focus();
        console.log('Web view user agent: [' + webView.useragent + ']');
    }

    function onWebViewMessage (message) {
        message = JSON.parse(message);
        //for now, this goes all searchManagers
        //This could be directed to the ${COMPONENT}Manager for ${PLUGIN}
        if(message.pluginType){
            if(message.pluginType in searchManagers){
                searchManagers[message.pluginType].onWebViewMessage(message);
            }
            if (message.pluginType in plugins) {
                var plugin = plugins[message.pluginType];
                if (plugin.hasOwnProperty('onWebViewMessage')) {
                    plugin.onWebViewMessage(message);
                }
            }
        }
        switch (message.action) {
        case 'open':
            open(message.url);
            break;
        case 'log':
            console.log.apply(console, JSON.parse(message.message));
            break;
        case 'quit':
            process.exit(0);
            break;
        }
    }

    self.addSearchManager = function (searchManager, pluginName){
        searchManagers[pluginName] = searchManager
        searchManager.on("invalidate", function (event) {
            sendToWebView({action: 'postEvent', event:event});
         });
        searchManager.on("showUI", self.showUI);
    };

    function sendToWebView (jsonAction) {
        if (webView) {
            var actionString = JSON.stringify(jsonAction);
            webView.postMessage(actionString);
        }
    }
};
var deviceManager = new ScratchDeviceManager();
var server = new ScratchDeviceServer(deviceManager);
var pluginTypes = require('require-all')({
    dirname: __dirname + '/plugins',
});

var plugins = {};



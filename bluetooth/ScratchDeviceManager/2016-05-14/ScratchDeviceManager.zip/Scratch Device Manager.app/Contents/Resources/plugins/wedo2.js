var WeDo2 = require('wedo2');

var WeDo2Plugin = function (app, searchManager) {
    var self = this;

    var pendingDevices = {};
    var openDevices = {};

    searchManager.on("listRequest", listDevices);

    function listDevices(){
        searchManager.lastSearchSample = searchManager.lastSearchSample.concat(WeDo2.list());
    }

    function Device (socket, wasOpenedEvent) {
        var self = this;

        var deviceId = wasOpenedEvent.deviceId;

        // Request that this device should be closed.
        self.close = function () {
            WeDo2.close(deviceId);
        };

        // Share the news that this device was closed.
        self.onDeviceWasClosed = function () {
            sendEvent(makeEvent('deviceWasClosed'));
        };

        self.getSocket = function () {
            return socket;
        };

        socket.on('motorOn', function (data) {
            WeDo2.motorOn(deviceId, data.motorIndex, data.power);
        });
        socket.on('motorOff', function (data) {
            WeDo2.motorOff(deviceId, data.motorIndex);
        });
        socket.on('motorBrake', function (data) {
            WeDo2.motorBrake(deviceId, data.motorIndex);
        });
        socket.on('setLED', function (data) {
            WeDo2.setLED(deviceId, data.rgb);
        });
        socket.on('playTone', function (data) {
            WeDo2.playTone(deviceId, data.tone, data.ms);
        });
        socket.on('stopTone', function () {
            WeDo2.stopTone(deviceId);
        });

        // TODO: remove listener when device/client connection is broken
        WeDo2.addEventListener('sensorChanged', function (event) {
            if (deviceId == event.deviceId) {
                sendEvent(event);
            }
        });

        function makeEvent (eventType) {
            return {type: eventType, deviceId: deviceId};
        }

        function sendEvent (event) {
            socket.emit(event.type, event);
        }

        self.compare = function (other){
            if (self.rssi < other.rssi) return 1;
            if (self.rssi > other.rssi) return -1;
            if (self.id < other.id) return 1;
            if (self.id > other.id) return -1;
            return 0;
        }; 

        sendEvent(wasOpenedEvent);
    }

    WeDo2.addEventListener('deviceWasOpened', function (event) {
        var deviceId = event.deviceId;
        if (deviceId) {
            if (deviceId in pendingDevices) {
                console.log('WeDo2 was opened: ' + deviceId);

                var socket = pendingDevices[deviceId];
                openDevices[deviceId] = new Device(socket, event);
                socket.emit("deviceWasOpened");
                delete pendingDevices[deviceId];
            }
            else {
                console.log('Received wasOpened event from device not pending: ' + deviceId);
            }
        }
        else {
            console.log('Received wasOpened with no deviceId');
        }
        searchManager.refreshUI();
    });

    WeDo2.addEventListener('deviceWasClosed', function (event) {
        handleDeviceClosed(event.deviceId);
    });

    function handleDeviceClosed (deviceId) {
        if (deviceId) {
            if (deviceId in pendingDevices) {
                console.log('Device was closed while opening: ' + deviceId);
                var socket = pendingDevices[deviceId];
                if (socket.connected) {
                    socket.disconnect(false);
                }
                delete pendingDevices[deviceId];
            }
            else if (deviceId in openDevices) {
                console.log('Device was closed: ' + deviceId);
                var device = openDevices[deviceId];
                device.onDeviceWasClosed();
                delete openDevices[deviceId];
            }
            else {
                console.log('Received wasClosed event from unexpected device: ' + deviceId);
            }
        }
        else {
            console.log('Received wasClosed with no deviceId');
        }
        searchManager.deviceWasClosed(deviceId);
    }


    function handleOpen (socket, data) {
        var error;
        if (!('deviceId' in data)) {
            error = 'No deviceId specified';
        }
        else if (data.deviceId in openDevices) {
            error = 'Device already open: ' + data.deviceId;
        }
        else {
            var deviceId = data.deviceId;
            // Should there be an error if the device is already pending?
            if (deviceId in pendingDevices) {
                console.log('Warning: Opening WeDo2 already pending: ' + deviceId);
            }
            pendingDevices[deviceId] = socket;
            WeDo2.open(deviceId);
            WeDo2.stopScanning();
            searchManager.stopSearching();
        }
        if (error) {
            console.log(error);
            socket.disconnect(false);
        }
    }

    function closeOrphanedDevices () {
        var deviceList = WeDo2.list();
        var numDevices = deviceList.length;
        for (var i = 0; i < numDevices; ++i) {
            var device = deviceList[i];
            if (device.connected) {
                var deviceId = device.id;
                if (!openDevices.hasOwnProperty(deviceId) && !pendingDevices.hasOwnProperty(deviceId)) {
                    console.log('WARNING: closing orphaned device: ' + deviceId);
                    WeDo2.close(deviceId);
                }
            }
        }
    }

    // Close all devices that match the specified device ID or socket.
    // If closeDeviceId=null, close all devices connected to the specified socket.
    // If closeSocket=null, close the specified device regardless of socket.
    // If both are null, close all devices regardless of socket.
    // TODO: can WeDo2.close() fail in the real world? if it does we won't clean up properly.
    function closeDevices (closeDeviceId, closeSocket) {
        closeOrphanedDevices();

        var deviceId;

        for (deviceId in pendingDevices) { if (pendingDevices.hasOwnProperty(deviceId)) {
            if ((closeDeviceId != null) && (closeDeviceId != deviceId)) continue;
            var socket = pendingDevices[deviceId];
            if ((closeSocket != null) && (closeSocket != socket)) continue;

            console.log('Closing pending device: ' + deviceId);
            WeDo2.close(deviceId);
        }}

        for (deviceId in openDevices) { if (openDevices.hasOwnProperty(deviceId)) {
            if ((closeDeviceId != null) && (closeDeviceId != deviceId)) continue;
            var device = openDevices[deviceId];
            if ((closeSocket != null) && (closeSocket != device.getSocket())) continue;

            console.log('Closing open device: ' + deviceId);
            device.close();
        }}
    }

    // TODO: take device ID as a parameter. For now, close all devices
    function handleClose () {
        closeDevices(null, null);
    }

    function handleDisconnect (socket, reason) {
        console.log('WeDo2 client disconnected: ' + reason);
        closeDevices(null, socket);
    }

    self.handleRequest = function (req, res, next) {
        switch (req.path) {
        case '/list':
            return searchManager.handleList(req, res, next);
        }
        console.log('Unknown request: ' + req.originalUrl);
        next();
    };

    self.handleConnect = function (socket, next) {
        console.log('WeDo2 client connected');
        socket.on('disconnect', function (reason) {
            handleDisconnect(socket, reason);
        });
        socket.on('open', function (data) {
            handleOpen(socket, data);
        });
        next();
    };

    searchManager.on('beginSearch', function (message) {
        WeDo2.scan();
    });

    searchManager.on('stopSearch', function(message){
        WeDo2.stopScanning();
    });

    searchManager.on('closeDevice', function(message){
        handleClose();
    });
};

WeDo2Plugin.pluginType = 'wedo2';

module.exports = WeDo2Plugin;

var noble = require("noble");

var BLEPlugin = function(app, searchManager, device_info){

    var self = this;
    console.log("info");
    console.log(device_info);
    var service_uuids = device_info.uuid;
    var rx_specs = device_info.read_characteristics;
    var tx_specs = device_info.write_characteristics;
    var name = device_info.device_name ? new RegExp(device_info.device_name) : null;
    var queue_enabled = device_info.hasOwnProperty("queue_enabled") ? device_info.queue_enabled : false;
    var pending_sockets = {};
    var open_devices = {};
    var available_devices = {};
    var known_peripherals = {};

    searchManager.on("listRequest", listDevices);

    function listDevices(){
        var list = [];
        for(var deviceID in available_devices){
            var device = available_devices[deviceID];
            var peripheral = known_peripherals[deviceID];
            peripheral.updateRssi(function(error, rssi){
                if(error){
                    console.log(error);
                }
                else{
                    device.rssi = parseInt(rssi);
                }
            });
            list.push({id: device.id, rssi: device.rssi}); 
        }
        searchManager.lastSearchSample = searchManager.lastSearchSample.concat(list); 
    }

    function BLEDevice (socket, deviceID, rx, tx){
        this.id = deviceID;
        this.rssi = null;
        self = this;
        self.connected = true;
        self.socket = socket;
        self.messageQueue = [];
        self.isSending = false;
        self.rx_characteristics = rx;
        self.tx_characteristics = tx;
        if(self.socket){
            self.listen();
        }

        self.compare = function(other){
            if(socket && other.socket)
                return 0;
            else if(socket)
                return -1;
            else if(other.socket)
                return 1;
            else
                return 0;
        };

        self.compile = function(type, channel, action){
            return (type << 5) | (channel << 3) | action;
        };
        function onWrite(err){
            if(err){
                console.log(err);
            }
            if(self.messageQueue.length > 0){
                var nextMessage;
                nextMessage = self.messageQueue.splice(0, Math.min(20, self.messageQueue.length));
                self.write(nextMessage);
            }
            else{
                self.isSending = false;
            }
        }
        
        self.write = function(byteArray, characteristic){
            characteristic.write(new Buffer(byteArray), !queue_enabled, onWrite);
        };

        self.sendBytes = function(bytes, characteristic){
            if(self.isSending && queue_enabled){
                self.messageQueue.push.apply(self.messageQueue, bytes);
            }
            else{
                self.isSending = true;
                self.write(bytes, characteristic);
            }
        };
       
        function deviceWasClosed(){
            searchManager.deviceWasClosed(self.id);
            self.socket.emit("deviceWasClosed");
            delete open_devices[self.id];
            self.connected = false;
        }

        self.close = function(){
            if(!self.connected){
                return;
            }
            var peripheral = known_peripherals[self.id]
            if(peripheral.state != "disconnected"){
                peripheral.disconnect(function(err){
                    if(err){
                        console.log(err);
                    }
                    else{
                        deviceWasClosed();
                    }
                });
            }
            else{
                deviceWasClosed();
            }
        };

        self.listen = function(){
            Object.keys(self.rx_characteristics).forEach(function(rx_uuid){
                self.rx_characteristics[rx_uuid].notify(true, function(err){
                    console.log("No notification service on " + rx_uuid);
                });

                self.rx_characteristics[rx_uuid].on('data', function(data){
                    var bytes = [];
                    bytes.push.apply(bytes, data);
                    self.socket.emit(rx_uuid, {data: bytes});
                });
            });

            self.socket.on('read', function(data){
                var rx_uuid = data.uuid;
                console.log(data);
                self.rx_characteristics[rx_uuid].read(function(error, data){
                    var bytes = [];
                    bytes.push.apply(bytes, data);
                    self.socket.emit(rx_uuid, {data: bytes});
                });
            });


            self.socket.on('write', function(data){
                var tx_uuid = data.uuid;
                console.log(tx_uuid);
                self.sendBytes(data.bytes, self.tx_characteristics[tx_uuid]);
            });
        };


    }
   
    noble.on("discover", function(peripheral){
        var device_id = peripheral.id;
        known_peripherals[device_id] = peripheral;

        if(!(peripheral.advertisement.serviceUuids.some(function(v){return service_uuids.indexOf(v) >=0;}))){
            console.log("REJECT ");
            console.log(peripheral.advertisement.serviceUuids);
            return;
        }
        if(name && !(peripheral.advertisement.localName.match(name))){
            return; 
        }
        console.log(peripheral);
        peripheral.connect(function(error){
            peripheral.once('disconnect', function(err){
                if(err){
                    console.log(err);
                }
                if(device_id in open_devices){
                    open_devices[device_id].close();
                }

            });
            noble.stopScanning();
            peripheral.discoverServices(service_uuids, function(error, services) {
                var uart_service = services[0];
                if(error || !uart_service){
                    peripheral.disconnect(function(err){ if(err) console.log(err); });
                    return;
                }
                uart_service.discoverCharacteristics(null, function(error, characteristics){
                    var rx = {};
                    var tx = {};
                    var io_characteristics = {};
                    for(var i in characteristics){
                        io_characteristics[characteristics[i].uuid] = characteristics[i];
                    }
                    for (var rx_uuid in rx_specs){
                        if(!(rx_uuid in io_characteristics)){
                            noble.startScanning(service_uuids, false);
                            return; 
                        }
                        else{
                            rx[rx_uuid] = io_characteristics[rx_uuid];
                        }
                    }
                    for (var tx_uuid in tx_specs){
                        if(!(tx_uuid in io_characteristics)){
                            noble.startScanning(service_uuids, false);
                            return; 
                        }
                        else{
                            tx[tx_uuid] = io_characteristics[tx_uuid];
                        }
                    }
                    if(device_id in pending_sockets){
                        open_devices[device_id] = new BLEDevice(pending_sockets[device_id], device_id, rx, tx);
                        delete pending_sockets[device_id];
                        delete available_devices[device_id];
                        open_devices[device_id].socket.emit('deviceWasOpened');
                        searchManager.connectedToDevice();
                    }
                    else{
                        available_devices[device_id] = new BLEDevice(null, device_id, rx, tx);
                   }
                });
            });
        });
    });

    searchManager.on('beginSearch', function (message) {
            if(noble.state === "poweredOn"){
                noble.startScanning(service_uuids, false);
            }
            else{
                noble.on("stateChange", function(state) {
                    if(state === "poweredOn"){
                            noble.startScanning(service_uuids, false);
                        }
                        else{
                            noble.stopScanning();
                        }
                });
            }
    });

    searchManager.on('closeDevice', function(message){
        for(var deviceID in open_devices){
            var device = open_devices[deviceID];
            device.close();
        }

    });

    self.handleConnect = function (socket, next) {
        socket.on('disconnect', function (reason) {
            handleDisconnect(socket, reason);
        });
        socket.on('open', function (data) {
            handleOpen(socket, data);
        });
        next();
    };

    function handleOpen (socket, data) {
        var error;
        if (!('deviceId' in data)) {
            error = 'No deviceId specified';
        }
        else if (data.deviceId in open_devices) {
            error = 'Device already open: ' + data.deviceId;
        }
        else {
            var deviceId = data.deviceId;
            // Should there be an error if the device is already pending?
            if (deviceId in pending_sockets) {
                console.log('Warning: Opening already pending ble device: ' + deviceId);
            }
            if(deviceId in available_devices){
                var device = available_devices[deviceId];
                device.socket = socket;
                device.listen();
                open_devices[deviceId] = device;
                delete available_devices[deviceId];
                socket.emit('deviceWasOpened');
                searchManager.connectedToDevice();
            }
            else{
                pending_sockets[deviceId] = socket;
            }
        }
        if (error) {
            console.log(error);
            socket.disconnect(false);
        }
    }

    function handleDisconnect (socket, reason) {
        var deviceId;
        for (deviceId in pending_sockets) {
            if (pending_sockets[deviceId] == socket) {
                delete pending_sockets[deviceId];
                searchManager.socketWasClosed(deviceId);
            }
        }

        for (deviceId in open_devices) {
            var device = open_devices[deviceId];
            if (device.socket == socket) {
                device.close();
                searchManager.socketWasClosed(deviceId);
            }
        }
    }

    self.handleRequest = function (req, res, next) {
        switch (req.path) {
        case '/list':
            return searchManager.handleList(req, res, next);
        }
        console.log('Unknown request: ' + req.originalUrl);
        next();
    };

};
module.exports = BLEPlugin;

# scratch-device-manager
Facilitates communication between Scratch and hardware devices

This project uses the Tint application framework, which is based on Node.JS

## Setup

First, install these prerequisites:
* Node.js 5.3.0, primarily for `npm` (see `nvm` section below)
* Tint 2.3.2: https://github.com/trueinteractions/tint2/releases
  * Some earlier versions intermittently crash when attempting to open the UI.

Then, clone this repository.

Finally, run `npm install` to install all dependencies.

### Optional: use `nvm` to install Node.js and npm

With `nvm` you will be able to switch between multiple versions of Node.js (and `npm`) easily. If you need a different
version of Node.js to work with another repository then `nvm` might help.
 
If you choose to use `nvm` it is recommended to uninstall any non-`nvm` versions of Node.js that you may have installed. 
 
* Install nvm by following the instructions here: https://github.com/creationix/nvm#install-script
* Download and install Node.js 5.3.0: `nvm install v5.3.0`

From now on, you may activate Node.js 5.3.0 by typing `nvm use v5.3.0`. This will only apply to your current session.

Alternatively, you may set Node.js 5.3.0 as the default with `nvm alias default v5.3.0`.

Finally, you can verify your version of Node.js by typing `node --version`.

## Test and run

Run `make dev` to build a development version of the application.

Run `make start` to run the development build. This is equivalent to `npm start` or `tint index.js`.

Run `make watch` to start `webpack` in watch mode so that it will rebuild the UI whenever files change in the `ui-src`
directory. This works well with `make start` but don't run `make dev` or `make ui` while `make watch` is running.

Run `make test` (or `npm test`) to run tests. At the moment this just runs `lint`.

## Building for distribution

First, ensure that the UI is built: `make clean ui`.

Then, run `make dist` to create a distributable build in the `dist` subdirectory.

This process requires uninstalling packages listed in the `devDependencies` section of `package.json`, so in order to
continue development (including `make ui`) you will need to run `npm install` afterward.

## Optional: use `node-wedo2` git repository

The `npm install` process will download the `node-wedo2` addon from GitHub, but it won't be configured as a git repository.
If you'd like to be able to use git commands like `git pull` on the `node-wedo2` repository, there are a few extra steps to take.

1. Clone the https://github.com/LLK/node-wedo2 repository as a sibling to this repository.
  For example, if you have `Documents/scratch-device-manager` you should also have `Documents/node-wedo2`.
2. Remove the `wedo2` module from `scratch-device-manager`:

  ```bash
  cd scratch-device-manager
  rm -r node_modules/wedo2
  ```
  
3. Use `npm link` to use the `node-wedo2` git repository instead:

  `npm link ../node-wedo2`

Note that using `node-wedo2` through `npm link` may cause warnings during `make dist` or `npm install`, and may defeat
some of the optimizations that `npm` can offer in newer versions. It may be best to use `npm link` only for development
and avoid it when using `make dist`.

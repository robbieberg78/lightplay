var CopyWebpackPlugin = require('copy-webpack-plugin');
var path = require('path');
var webpack = require('webpack');

var entries = {home: './views/home.jsx'};
var copyItems = [
    {from: 'images', to: 'images'},
    {from: 'home.html'}
];

var devMode = (process.env.NODE_ENV !== 'production');
if (devMode) {
    entries['test'] = './views/test.jsx';
    copyItems.push({from: 'test.html'});
}


// Config
module.exports = {
    context: path.resolve(__dirname, 'ui-src'),
    entry: entries,
    devtool: 'source-map',
    output: {
        path: path.resolve(__dirname, 'ui'),
        filename: 'js/[name].bundle.js'
    },
    module: {
        loaders: [
            {
                test: /\.jsx$/,
                loader: 'babel-loader',
                include: path.resolve(__dirname, 'ui-src'),
                query: {
                    presets: ['react', 'es2015']
                }
            },
            {
                test: /\.js$/,
                loader: 'babel-loader',
                query: {
                    presets: ['es2015']
                }
            },
            {
                test: /\.json$/,
                loader: 'json-loader'
            },
            {
                test: /\.scss$/,
                loader: 'style!css!autoprefixer-loader?browsers=last 3 versions!sass'
            },
            {
                test: /\.(png|jpg|gif|eot|svg|ttf|woff)$/,
                loader: 'url-loader'
            }
        ]
    },
    node: {
        fs: 'empty'
    },
    plugins: [
        new CopyWebpackPlugin(copyItems),
        //new webpack.optimize.UglifyJsPlugin({
        //    compress: {
        //        warnings: false
        //    }
        //}),
        new webpack.optimize.OccurenceOrderPlugin()
    ]
};
